
<?php $__env->startSection('content'); ?>
<title>Barang | Kasir</title>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Data Barang</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <?php if( Session::get('masuk') !=""): ?>
            <div class='alert alert-success'><center><b><?php echo e(Session::get('masuk')); ?></b></center></div>        
            <?php endif; ?>
            <?php if( Session::get('update') !=""): ?>
            <div class='alert alert-success'><center><b><?php echo e(Session::get('update')); ?></b></center></div>        
            <?php endif; ?>
            <div class="row">
                <div class="col-md-6">
                    <button class="btn btn-success" data-toggle="modal" data-target="#tambah">Tambah Data</button>
                </div>
                <div class="col-md-6 text-right">
                    <a href="/cetak" class="btn btn-warning">Cetak Harga</a>
                </div>
            </div>
            <br>
            <br>
            <table id="dataTable" class="table table-bordered" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Barcode</th>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Kategori</th>
                        <th>Jumlah</th>
                        <th>Harga</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$i); ?></td>
                        <td> <img src="data:image/png;base64,<?php echo e(DNS1D::getBarcodePNG($u->id_barang, 'C39')); ?>" height="60" width="180"></td>
                        <td><?php echo e($u->id_barang); ?></td>
                        <td><?php echo e($u->nama_barang); ?></td>
                        <td><?php echo e($u->nama_kategori); ?></td>
                        <td><?php echo e($u->jumlah_barang); ?></td>
                        <td><?php echo e($u->harga_barang); ?></td>
                        <td><a href="/barang/edit/<?php echo e($u->id_barang); ?>" class="btn btn-primary btn-sm ml-2">Edit</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="tambah" class="modal fade" tabindex="-1" role="dialog">
<div class="modal-dialog" role="document">
    <!-- Modal content-->
    <div class="modal-content">
    <div class="modal-header">
        <h4 class="modal-title">Masukan Data</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-body">
    <form action="/barang/store" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="">Kode Barang</label>
            <input type="text" name="id_barang" class="form-control"  required>
        </div>
        <div class="form-group">
            <label for="">Nama Barang</label>
            <input type="text" name="nama_barang" class="form-control"  required>
        </div>
        <div class="form-group">
            <label for="">Kategori</label>
            <select name="kategori_id" id="" class="form-control">
                <option value="" disabled selected>Pilih Kategori</option>
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($k->id_kategori); ?>"><?php echo e($k->nama_kategori); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="">Jumlah</label>
            <input type="text" name="jumlah_barang" class="form-control"  required>
        </div>
        <div class="form-group">
            <label for="">Harga</label>
            <input type="text" name="harga_barang" class="form-control"  required>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
    </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kasir2\resources\views/barang/index.blade.php ENDPATH**/ ?>